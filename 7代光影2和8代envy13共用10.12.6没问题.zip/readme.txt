此文件可在 光影精灵2 pro (7代处理 以及 Envy13 17年款 (8代处理器)上使用
使用前,请修改 config.plist 的 SMBIOS 
SerialNumber 序列号 1234 改一下
SmUUID 的 123456789012 改成你的网卡 Mac 地址不要冒号
或者用 Clover Configurator 生成
